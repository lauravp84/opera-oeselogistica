import { kv } from '@vercel/kv';
const KEY = 'ppc_grade_estado';
export default async function handler(req, res) {
  if (req.method === 'GET') {
    const s = await kv.get(KEY);
    return res.status(200).json(s || {});
  }
  if (req.method === 'POST') {
    await kv.set(KEY, req.body);
    return res.status(200).json({ ok: true });
  }
  res.status(405).end();
}
